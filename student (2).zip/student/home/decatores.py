# decorators.py

from django.contrib.auth.decorators import user_passes_test

def admin_required(view_func):
    actual_decorator = user_passes_test(
        lambda u: u.is_active and u.is_superuser,
        login_url='your_login_url',  # replace with your login URL
    )
    return actual_decorator(view_func)
