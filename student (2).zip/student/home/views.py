from django.shortcuts import render,HttpResponse, redirect
from django.contrib.auth.models import User
from django.contrib.auth import logout, authenticate,login
from datetime import datetime
from home.models import Contact,Course,Student

from django.contrib import messages
from django.core.mail import send_mail
from userlogin import settings


#dummy
#from django.views.generic import ListView
from home.models import Contact,Course
from django.contrib.auth.forms import UserCreationForm
from home.forms import CreateUserForm
from django.contrib.auth.decorators import login_required
from .models import  Destination
# views.py



#from django.views.generic import ListView, CreateView # new
#from django.urls import reverse_lazy # new

# from home.forms import ImageForm # new

#dummy


#password for test user is 1234$sahil
# Create your views here.

@login_required(login_url='login')
def index(request):
    if request.user.is_anonymous:
        return redirect("/login")
    return render(request,'index.html')

def registerPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()

        if request.method=="POST":
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user)

                return redirect('login')
                
        context = {'form':form}
        return render(request, 'register.html', context)

def loginUser(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method=="POST":
            username=request.POST.get('username')
            password=request.POST.get('password')
            
            # check if user has entered correct credentials
            user = authenticate(username=username, password=password)
            if user is not None:
                # A backend authenticated the credentials
                login(request,user)
                return redirect("/")

            else:  
                # No backend authenticated the credentials
                messages.info(request, 'Username OR password is incorrect')
                return render(request,'login.html')
            

        return render(request,'login.html')

def logoutUser(request):
    logout(request)
    return redirect("/login")








def blog(request):

    dests = Destination.objects.all()

    return render(request,"blog.html", {'dests' : dests})

@login_required(login_url='login')

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        father = request.POST.get('father')
        mother = request.POST.get('mother')
        
        email = request.POST.get('email')

        phone = request.POST.get('phone')
        phone1 = request.POST.get('phone1')
        gender = request.POST.get('gender')
        religion = request.POST.get('religion')        
        Address1 = request.POST.get('Address1')
        Address2 = request.POST.get('Address2')
       
        file = request.POST.get('file')
        Aadhar = request.POST.get('Aadhar')
        desc = request.POST.get('desc') 
        document = Contact.objects.create(name=name,father=father,mother=mother,email=email, phone=phone, phone1=phone1,Address1=Address1, Address2=Address2,file=file,Aadhar=Aadhar, desc=desc,gender=gender,religion=religion)#JeeAppNo=JeeAppNo)
        document.save()
        messages.success(request, 'Your message has been sent!---------------------->Go To Fill Academic')
    return render(request, "contact.html")

def student(request):
    if request.method == "POST":
        Username = request.POST.get('Username')
        email=request.POST.get('email')
        sslc=request.POST.get('sslc')
        sslcmark=request.POST.get('sslcmark')
        hscschool=request.POST.get('hscschool')
        hscmark=request.POST.get('hscmark')
        marksheet=request.POST.get('marksheet')
        rank = Student.objects.order_by('-hscmark')
        

        if int(hscmark)>570:
            print(f'{Username}-your mark eligible for this admission')
            #sub='Kongu enginieering college'
            #msg='your application was successfully sumbited wait for the result'
            send_mail(
                    'Kongu Enginieering college',
                     f"dear {Username} ,your mark: {hscmark},is eligible for this admission, next step course registration!,Your Course code is - 23MCR100",
                     settings.EMAIL_HOST_USER,
                     [email],
                     fail_silently=False,
            ),
        else:
            print(f'{Username}-you are not eligible for this admission')
            send_mail(
                    'Kongu Enginieering college',
                    f"dear student your mark not applicable",

                     settings.EMAIL_HOST_USER,
                     [email],
                     fail_silently=False,
            ),
                
                    
        
            #messages.success1(request,'Mail sent Successfully')
        
        document=Student.objects.create(Username=Username,email=email,hscschool=hscschool,hscmark=hscmark,sslc=sslc,sslcmark=sslcmark,marksheet=marksheet)
        document.save()

    return render(request,"chat.html")   



def course(request):
    if request.method == "POST":
        studentname = request.POST.get('studentname')
        hscpercentage = request.POST.get('hscpercentage')
        email=request.POST.get('email')
        ugpercentage=request.POST.get('ugpercemtage')
        coursecode=request.POST.get('code')
        
        #group=request.POST.get('group')
        course= request.POST.get('course')
        if int(hscpercentage)>90:
            print('success')
            send_mail(
                    'Kongu Enginieering college',
                     f"Dear {studentname},\n\nYou have successfully selected the course: {course}.\n\nHSC Percentage: {hscpercentage}%\n\nThank you for your selection for this code",
                    settings.EMAIL_HOST_USER,
                    [email],
                    fail_silently=False,
                
                    
            ),
        else:
            print("yes")
            send_mail(
                    'Kongu Enginieering college',
                     f"your mark not eligible this admission",
                    settings.EMAIL_HOST_USER,
                    [email],
                    fail_silently=False,
                
                    
            ),

        document=Course.objects.create(studentname=studentname,hscpercentage=hscpercentage,course=course,ugpercentage=ugpercentage)
        document.save()


    return render(request,"course.html")    


